import { RouterModule, Routes } from '@angular/router';

export const routes: Routes = [

  // {
  //   path: '',
  //   redirectTo: '/home', // Default route to home
  //   pathMatch: 'full'
  // }
];

// @NgModule({
//   imports: [RouterModule.forRoot(routes)], // Import routes configuration
//   exports: [RouterModule]
// })
// export class AppRoutingModule { }
